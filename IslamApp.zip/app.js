// Zukünftige Funktionen für die Islam-App
console.log('Islam App geladen!');